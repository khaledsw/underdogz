<?php
/**
 * Transactional Emails Controller
 *
 * eventon email class handles email templates and sending out emails
 *
 * @class 		EVO_Emails
 * @version		2.2.9
 * @package		eventon/Classes/Emails
 * @category	Class
 * @author 		AJDE
 */
class EVO_Emails {

}